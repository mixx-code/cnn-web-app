/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true, // Abaikan error TypeScript saat build
  },
};

export default nextConfig;
